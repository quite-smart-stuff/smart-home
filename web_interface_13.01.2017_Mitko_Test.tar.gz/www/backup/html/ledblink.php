<?php
system("sudo python /var/www/ledblink.py");
?>

