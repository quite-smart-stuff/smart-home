<html>
<body>
<?php
system("sudo python ../door_open.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
