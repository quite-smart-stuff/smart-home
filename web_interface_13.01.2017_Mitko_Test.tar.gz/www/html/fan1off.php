<?php
system("sudo python ../fan1off.py");
?>
