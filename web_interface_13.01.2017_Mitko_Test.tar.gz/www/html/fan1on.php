<?php
system("sudo python ../fan1on.py");
?>
