<?php
system("sudo python ../fan2off.py");
?>
