<?php
system("sudo python ../fan2on.py");
?>
