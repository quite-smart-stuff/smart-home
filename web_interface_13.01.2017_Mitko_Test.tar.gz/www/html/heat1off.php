<?php
system("sudo python ../heat1off.py");
?>
