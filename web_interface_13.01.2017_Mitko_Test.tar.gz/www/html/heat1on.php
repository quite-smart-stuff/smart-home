<?php
system("sudo python ../heat1on.py");
?>
