<?php
system("sudo python ../heat2off.py");
?>
