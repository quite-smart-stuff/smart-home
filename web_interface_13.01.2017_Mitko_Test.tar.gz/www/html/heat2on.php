<?php
system("sudo python ../heat2on.py");
?>
