<html>
<body>
<?php
system("sudo python ../lcd.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
