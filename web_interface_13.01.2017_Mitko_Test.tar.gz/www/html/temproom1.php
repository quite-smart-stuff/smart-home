<?php
system("sudo python ../tmp_0x48_0x90.py");
?>
