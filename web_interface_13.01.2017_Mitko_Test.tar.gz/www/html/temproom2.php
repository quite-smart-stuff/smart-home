<?php
system("sudo python ../tmp_0x49_0x92.py");
?>
