<?php
system("sudo python /var/www/ledoff.py");
?>

