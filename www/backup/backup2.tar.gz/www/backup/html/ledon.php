<?php
system("sudo python /var/www/ledon.py");
?>

