<html>
<head>
<link rel="icon" type="image/png" href="icon.png">
<meta />
<title>
Control Home System
</title>
</head>
<body>
<form>
<button type="button" onclick="parent.location='ledon.php'">btn on</button>
<button type="button" onclick="parent.location='ledoff.php'">btn off</button>
<button type="button" onclick="parent.location='ledblink.php'">btn blink</button>
</form>
</body>
</html>
