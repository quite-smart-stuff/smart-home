import RPi.GPIO as GPIO

GPIO.setwarnings(False)

def buzzeron(pin):
        GPIO.output(pin,GPIO.HIGH)
        print("buzzer on")
        return

GPIO.setmode(GPIO.BOARD)

GPIO.setup(13, GPIO.OUT)

buzzeron(13)

#GPIO.cleanup()
