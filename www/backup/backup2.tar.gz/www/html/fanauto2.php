<html>
<body>
<?php
system("sudo python ../fanauto2.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
