<html>
<body>
<?php
system("sudo python ../fanoff1.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
