<html>
<body>
<?php
system("sudo python ../ledon2.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
