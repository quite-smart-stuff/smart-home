import RPi.GPIO as GPIO

GPIO.setwarnings(False)

def lamp1off(pin):
        GPIO.output(pin,GPIO.LOW)
        print("lamp 1 off")
        return

GPIO.setmode(GPIO.BOARD)

GPIO.setup(31, GPIO.OUT)

lamp1off(31)

GPIO.cleanup()
