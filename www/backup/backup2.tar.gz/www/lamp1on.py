import RPi.GPIO as GPIO

GPIO.setwarnings(False)

def lamp1on(pin):
        GPIO.output(pin,GPIO.HIGH)
        print("lamp 1 on")
        return

GPIO.setmode(GPIO.BOARD)

GPIO.setup(31, GPIO.OUT)

lamp1on(31)

#GPIO.cleanup()
