import RPi.GPIO as GPIO

GPIO.setwarnings(False)

def lamp2off(pin):
        GPIO.output(pin,GPIO.LOW)
        print("lamp 2 off")
        return

GPIO.setmode(GPIO.BOARD)

GPIO.setup(32, GPIO.OUT)

lamp2off(32)

GPIO.cleanup()
