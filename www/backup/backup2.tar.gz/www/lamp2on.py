import RPi.GPIO as GPIO

GPIO.setwarnings(False)

def lamp2on(pin):
        GPIO.output(pin,GPIO.HIGH)
        print("lamp 2 on")
        return

GPIO.setmode(GPIO.BOARD)

GPIO.setup(32, GPIO.OUT)

lamp2on(32)

#GPIO.cleanup()
