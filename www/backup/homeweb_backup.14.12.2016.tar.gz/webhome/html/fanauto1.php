<html>
<body>
<?php
system("sudo python ../fanauto1.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
