<html>
<body>
<?php
system("sudo python ../fanoff2.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
