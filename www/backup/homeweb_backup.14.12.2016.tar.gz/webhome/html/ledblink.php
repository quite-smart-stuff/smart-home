<html>
<body>
<?php
system("sudo python ../ledblink.py");
?>
<a href="webhome.php">back</a>
</body>
</html>
