<html>
<body>
<?php
system("sudo python ../ledon1.py &");
?>
<a href="webhome.php">back</a>
<!--
<form method="POST" action="comments.php">
<input type="text" name="avtor"><br/>
<textarea name="komentar">
</textarea><br/>
<input type="submit" name="submit" value="Enter">
</form>
$html = file_post_html('http://sinoptik.bg/sofia-bulgaria-100727011?location');
if ($url_home == false) {
  // treat error
} else {
  // handle good case
} 
-->
</body>
</html>
